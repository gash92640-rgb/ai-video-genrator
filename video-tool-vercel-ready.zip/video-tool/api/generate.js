export default async function handler(req,res){
try{
const {prompt}=JSON.parse(req.body);
const response=await fetch("https://api-inference.huggingface.co/models/cerspense/zeroscope_v2_576w",{
method:"POST",
headers:{
"Authorization":"Bearer "+process.env.HF_TOKEN,
"Content-Type":"application/json"
},
body:JSON.stringify({inputs:prompt})
});
const blob=await response.blob();
const buffer=Buffer.from(await blob.arrayBuffer());
res.setHeader('Content-Type','video/mp4');
res.send(buffer);
}catch(e){
res.status(500).json({error:e.message});
}
}
